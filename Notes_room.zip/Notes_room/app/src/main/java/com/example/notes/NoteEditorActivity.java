package com.example.notes;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.room.Room;

import java.util.HashSet;

public class NoteEditorActivity extends AppCompatActivity {

    // Define note ID and Button for button
    private int noteId;
    private LiveData<Note> noteLiveData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_editor);

        // Define our Button and EditText
        Button saveNoteBtn = (Button) findViewById(R.id.save_new_note);
        EditText editText = findViewById(R.id.noteText);

        // Fetch data that is passed from MainActivity
        Intent intent = getIntent();

        LocalDataBase localDataBase = Room.databaseBuilder(this, LocalDataBase.class, "local.db").build();

        // Accessing the data using key and value
        noteId = intent.getIntExtra("noteId", -1);

        if (noteId != -1) {
            noteLiveData = localDataBase.noteDao().getById(noteId);
            noteLiveData.observe(this, note -> {
                editText.setText(note.getValue());
            });
        }

        // Save New note
        saveNoteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String noteText = editText.getText().toString();
                Note note;
                if (noteId != -1){
                    note = noteLiveData.getValue();
                }
                else {
                    note = new Note();
                }
                note.setValue(noteText);
                new Thread(() -> localDataBase.noteDao().insert(note))
                        .start();

                // Going from MainActivity to NotesEditorActivity
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        noteLiveData.removeObservers(this);
    }
}