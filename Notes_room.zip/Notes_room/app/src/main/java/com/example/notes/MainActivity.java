package com.example.notes;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.room.Room;

import java.util.List;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

    private LiveData<List<Note>> noteLiveData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Define our ListView
        ListView listView = findViewById(R.id.listView);

        //init db
       LocalDataBase localDataBase = Room.databaseBuilder(this, LocalDataBase.class, "local.db").build();
       noteLiveData = localDataBase.noteDao().getAll();

       noteLiveData.observe(this, notes -> {
          // Populate the list with data from the adapter
          ArrayAdapter<String> arrayAdapter;
          arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_expandable_list_item_1,
                  notes.stream()
                          .map(Note::getValue)
                          .collect(Collectors.toList()));
          listView.setAdapter(arrayAdapter);
      });




        // On a normal click on a list item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // Going from MainActivity to NotesEditorActivity
                Intent intent = new Intent(getApplicationContext(), NoteEditorActivity.class);
                intent.putExtra("noteId", noteLiveData.getValue().get(i).getId());
                startActivity(intent);
            }
        });

        // When pressing on a list item
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                final int itemToDelete = i;
                // To delete the data from the App
                new AlertDialog.Builder(MainActivity.this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("Är du säkert?")
                        .setMessage("Vill du radera den här anteckningen?")
                        .setPositiveButton("Ja", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                new Thread(() -> {
                                    localDataBase.noteDao().delete(noteLiveData.getValue().get(itemToDelete));
                                }).start();
                            }
                        })
                        .setNegativeButton("Nej", null).show();
                return true;
            }
        });
    }

    // Add new note
    public void AddNote(View view) {
        // Going from MainActivity to NotesEditorActivity
        Intent intent = new Intent(getApplicationContext(), NoteEditorActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        noteLiveData.removeObservers(this);
    }
}